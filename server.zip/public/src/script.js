const { fetch, Headers } = window;

console.log('hello world');

const button = document.querySelector('#button-01');

button.addEventListener('click', async () => {
  const headers = new Headers();
  headers.set('Authorization', 'authorized');

  const response = await fetch('/api/user', {
    headers
  });
  const json = await response.json();

  const span = document.createElement('span');
  if (json) {
    span.innerHTML = json.text;
    document.querySelector('body').appendChild(span);
  } else {
    console.log(json);
  }
});
