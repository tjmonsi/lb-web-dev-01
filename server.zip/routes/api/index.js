const { Router } = require('express');
const api = Router();
api.use('/user', require('./user'));
module.exports = api;
