const { Router } = require('express');
const auth = require('../../../middlewares/auth');
const logger = require('../../../middlewares/logger');
const getAll = require('./get-all');
const getOne = require('./get-one');
const create = require('./create');
const update = require('./update');
const remove = require('./remove');

const user = Router();
// get all users
user.get('/', auth, logger, getAll);

// get one user
user.get('/:userId', getOne);

// create one user
user.post('/', create);

// update one user
user.put('/:userId', update);

// remove one user
user.delete('/:userId', remove);

module.exports = user;
