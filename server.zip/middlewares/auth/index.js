module.exports = (req, res, next) => {
  const { headers } = req;

  if (!headers['authorization']) {
    return res.json({
      text: 'Not Authenticated'
    });
  }

  next();
};
